from pathlib import Path
import csv


csv_path = Path(
    r"C:\Users\WilliamY9000P\Desktop\USC_Racing"
    r"\real_data_staging\exported\i2_lap3_validation.csv"
)

target_channels = [
    "Engine Speed",
    "Vehicle Speed",
    "Throttle Position",
    "Steering Angle",
    "Wheel Speed Front Left",
    "Wheel Speed Front Right",
]

duration_s = None
header = None
units = None
header_row_number = None

with csv_path.open(
    "r",
    encoding="utf-8-sig",
    newline="",
    errors="replace",
) as file:
    reader = csv.reader(file)

    for row_number, row in enumerate(reader, start=1):
        for index, cell in enumerate(row[:-1]):
            if cell.strip() == "Duration":
                try:
                    duration_s = float(row[index + 1])
                except ValueError:
                    pass

        if row and row[0].strip().casefold() == "time":
            header = row
            units = next(reader, [])
            header_row_number = row_number
            break

    if header is None:
        raise SystemExit(
            "No data header beginning with 'Time' was found."
        )

    channel_indices = {}

    for target in target_channels:
        matches = [
            index
            for index, name in enumerate(header)
            if name.strip().casefold() == target.casefold()
        ]

        channel_indices[target] = matches

    nonempty_counts = {
        target: 0
        for target in target_channels
    }

    data_rows = 0

    for row in reader:
        if not row or not any(cell.strip() for cell in row):
            continue

        data_rows += 1

        for target, indices in channel_indices.items():
            for index in indices:
                if index < len(row) and row[index].strip():
                    nonempty_counts[target] += 1

print(f"Header row number: {header_row_number}")
print(f"Total exported columns: {len(header)}")
print(f"Non-empty data rows: {data_rows}")

if duration_s is not None:
    print(f"Exported duration: {duration_s:g} seconds")
else:
    print("Exported duration: not detected")

print("Target-channel structure:")

for target in target_channels:
    indices = channel_indices[target]

    if not indices:
        print(f"- {target}: not found")
        continue

    index = indices[0]
    unit = (
        units[index].strip()
        if index < len(units)
        else ""
    )
    count = nonempty_counts[target]

    if duration_s and duration_s > 0:
        approximate_rate = count / duration_s
        rate_text = f"{approximate_rate:.2f} Hz"
    else:
        rate_text = "unknown"

    print(
        f"- {target}: column={index + 1}, "
        f"unit={unit!r}, samples={count}, "
        f"approximate_rate={rate_text}"
    )