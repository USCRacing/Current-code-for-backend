from collections import Counter
from itertools import islice
from pathlib import Path
import csv


csv_path = Path(
    r"C:\Users\WilliamY9000P\Desktop\USC_Racing"
    r"\real_data_staging\exported\i2_lap3_validation.csv"
)

with csv_path.open("rb") as file:
    prefix = file.read(65536)

if prefix.startswith((b"\xff\xfe", b"\xfe\xff")):
    encoding = "utf-16"
else:
    encoding = None

    for candidate in ("utf-8-sig", "cp1252"):
        try:
            prefix.decode(candidate)
            encoding = candidate
            break
        except UnicodeDecodeError:
            continue

    if encoding is None:
        encoding = "utf-8-sig"

sample = prefix.decode(encoding, errors="replace")

try:
    dialect = csv.Sniffer().sniff(
        sample,
        delimiters=",;\t",
    )
    delimiter = dialect.delimiter
except csv.Error:
    delimiter = ","

print(f"File size: {csv_path.stat().st_size:,} bytes")
print(f"Detected encoding: {encoding}")
print(f"Detected delimiter: {delimiter!r}")

with csv_path.open(
    "r",
    encoding=encoding,
    newline="",
    errors="replace",
) as file:
    reader = csv.reader(file, delimiter=delimiter)
    rows = list(islice(reader, 12))

for index, row in enumerate(rows, start=1):
    classifications = []

    for cell in row:
        value = cell.strip()

        if value == "":
            classifications.append("empty")
            continue

        try:
            float(value)
            classifications.append("numeric")
        except ValueError:
            classifications.append("text")

    counts = Counter(classifications)

    print(
        f"Row {index}: fields={len(row)}, "
        f"text={counts['text']}, "
        f"numeric={counts['numeric']}, "
        f"empty={counts['empty']}"
    )

    labels = [
        cell.strip()[:60]
        for cell, category in zip(row, classifications)
        if category == "text" and cell.strip()
    ][:20]

    if labels:
        print(f"  Text labels: {labels}")