\# Day 9 Synthetic Integration Rehearsal


Date: 2026-09-20


Status: Completed with synthetic data; real i2-exported CSV still pending.



\## Purpose



Validate the complete telemetry ingestion and read-only API path while the

real CSV export from the historical `.ld` and `.ldx` files is unavailable.



\## Input Used



Fixture:



`sample\_data/demo\_telemetry.csv`



Required normalized columns:



`session\_name,run\_name,source\_file,channel\_name,unit,sample\_rate\_hz,timestamp\_s,value`



The fixture contains:



\- 1 test session

\- 1 imported run

\- 2 channels

\- 6 measurements



\## Import Verification



Command:



```text

python manage.py import\_telemetry sample\_data\\demo\_telemetry.csv