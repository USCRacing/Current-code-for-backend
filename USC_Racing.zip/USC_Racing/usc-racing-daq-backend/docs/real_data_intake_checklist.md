# Real Telemetry Data Intake Checklist

Use this checklist when receiving telemetry data exported from historical
`.ld` or `.ldx` files through i2.

## 1. Source information

- [ ] Record the original `.ld` or `.ldx` filename.
- [ ] Record the exported CSV filename.
- [ ] Record which test session and run produced the data.
- [ ] Record who exported the data and which export settings were used.
- [ ] Keep raw `.ld` and `.ldx` files outside Git.

## 2. CSV file format

- [ ] Confirm that the file opens as a CSV text file.
- [ ] Confirm the delimiter: comma, semicolon, tab, or another character.
- [ ] Confirm the text encoding, preferably UTF-8.
- [ ] Confirm whether the first row contains column names.
- [ ] Confirm whether the file uses long format or wide format.
- [ ] Check for blank rows or repeated header rows.

Long format example:

```text
timestamp_s,channel_name,unit,value
0.0,Engine RPM,rpm,3000
0.1,Engine RPM,rpm,3150
```

Wide format example:

```text
timestamp_s,Engine RPM,Vehicle Speed
0.0,3000,0
0.1,3150,12.5
```

The current importer expects normalized long-format data.

## 3. Time data

- [ ] Confirm whether time is measured in seconds, milliseconds, or microseconds.
- [ ] Confirm whether time starts at zero.
- [ ] Check whether any timestamps are negative.
- [ ] Check whether timestamps are sorted.
- [ ] Check whether duplicate timestamps exist for the same channel.

## 4. Channel data

For every exported channel, record:

- [ ] Channel name.
- [ ] Unit.
- [ ] Sample rate.
- [ ] Minimum and maximum value.
- [ ] Whether missing values exist.
- [ ] Whether invalid text values such as `NaN`, `null`, or `N/A` exist.

Initial recommended channels:

- [ ] Engine RPM.
- [ ] Vehicle Speed.
- [ ] Throttle Position, if available.
- [ ] Brake Pressure, if available.

## 5. Run structure

- [ ] Confirm whether the CSV contains one run or multiple runs.
- [ ] Confirm whether channel sample rates differ.
- [ ] Confirm whether every channel covers the same time range.
- [ ] Record the approximate number of rows.
- [ ] Record the CSV file size.

## 6. Normalization requirements

Before using the current importer, data must contain these columns:

```text
session_name
run_name
source_file
channel_name
unit
sample_rate_hz
timestamp_s
value
```

If the i2 export has a different structure, create a conversion step instead
of manually editing a large CSV.

## 7. Validation after import

Run:

```text
python manage.py check
python manage.py import_telemetry path\to\real_data.csv
python manage.py test telemetry
```

Then verify:

- [ ] The importer finishes without an exception.
- [ ] The expected TestSession and Run exist.
- [ ] The expected channels exist.
- [ ] Measurement counts are reasonable.
- [ ] API filters return the expected channel and time range.
- [ ] Re-importing the same CSV does not create duplicates.