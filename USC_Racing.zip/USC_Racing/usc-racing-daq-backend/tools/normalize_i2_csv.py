import argparse
import csv
import math
from collections import Counter
from pathlib import Path


DEFAULT_CHANNELS = [
    "Engine Speed",
    "Vehicle Speed",
    "Throttle Position",
    "Steering Angle",
    "Wheel Speed Front Left",
    "Wheel Speed Front Right",
]

OUTPUT_FIELDS = [
    "session_name",
    "run_name",
    "source_file",
    "channel_name",
    "unit",
    "sample_rate_hz",
    "timestamp_s",
    "value",
]


def parse_arguments():
    parser = argparse.ArgumentParser(
        description=(
            "Convert a MoTeC i2 wide CSV export into the "
            "normalized telemetry CSV format."
        )
    )
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("output_csv", type=Path)
    parser.add_argument(
        "--channel",
        action="append",
        dest="channels",
        help=(
            "Exact channel name to include. May be repeated. "
            "Defaults to the pilot channel set."
        ),
    )
    parser.add_argument(
        "--stride",
        type=int,
        default=10,
        help="Keep every Nth valid time row. Default: 10.",
    )
    parser.add_argument(
        "--max-time",
        type=float,
        default=15.0,
        help=(
            "Maximum relative time in seconds. "
            "Default: 15."
        ),
    )
    parser.add_argument(
        "--session-name",
        default="Real Data Validation",
    )
    parser.add_argument(
        "--run-name",
        default="Lap 3 Pilot",
    )
    parser.add_argument(
        "--source-file",
        default=None,
        help=(
            "Safe source label stored in the database. "
            "Defaults to the input CSV filename."
        ),
    )
    parser.add_argument(
        "--overwrite",
        action="store_true",
    )
    return parser.parse_args()


def parse_finite_number(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None

    if not math.isfinite(number):
        return None

    return number


def number_text(value):
    return format(value, ".12g")


def main():
    arguments = parse_arguments()

    if arguments.stride <= 0:
        raise SystemExit("--stride must be a positive integer.")

    if arguments.max_time <= 0:
        raise SystemExit("--max-time must be positive.")

    if not arguments.input_csv.is_file():
        raise SystemExit(
            f"Input CSV not found: {arguments.input_csv}"
        )

    if (
        arguments.output_csv.exists()
        and not arguments.overwrite
    ):
        raise SystemExit(
            "Output CSV already exists. Use --overwrite only "
            "after verifying the target path."
        )

    channels = arguments.channels or DEFAULT_CHANNELS
    source_file = (
        arguments.source_file
        or arguments.input_csv.name
    )

    input_sample_rate_hz = None
    header = None
    units = None
    header_row_number = None

    arguments.output_csv.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with arguments.input_csv.open(
        "r",
        encoding="utf-8-sig",
        newline="",
        errors="replace",
    ) as input_file:
        reader = csv.reader(input_file)

        for row_number, row in enumerate(
            reader,
            start=1,
        ):
            for index, cell in enumerate(row[:-1]):
                if cell.strip() == "Sample Rate":
                    input_sample_rate_hz = (
                        parse_finite_number(
                            row[index + 1]
                        )
                    )

            if (
                row
                and row[0].strip().casefold()
                == "time"
            ):
                header = row
                units = next(reader, [])
                header_row_number = row_number
                break

        if header is None:
            raise SystemExit(
                "No data header beginning with 'Time' "
                "was found."
            )

        if not input_sample_rate_hz:
            raise SystemExit(
                "A valid input sample rate was not found."
            )

        normalized_header = [
            name.strip().casefold()
            for name in header
        ]

        try:
            time_index = normalized_header.index("time")
        except ValueError as error:
            raise SystemExit(
                "The Time column was not found."
            ) from error

        channel_indices = {}

        for channel in channels:
            matches = [
                index
                for index, name in enumerate(header)
                if (
                    name.strip().casefold()
                    == channel.casefold()
                )
            ]

            if not matches:
                raise SystemExit(
                    f"Required channel not found: {channel}"
                )

            if len(matches) > 1:
                raise SystemExit(
                    f"Duplicate channel columns found: "
                    f"{channel}"
                )

            channel_indices[channel] = matches[0]

        output_rate_hz = (
            input_sample_rate_hz
            / arguments.stride
        )

        channel_counts = Counter()
        valid_time_rows = 0
        written_rows = 0
        first_time = None

        with arguments.output_csv.open(
            "w",
            encoding="utf-8",
            newline="",
        ) as output_file:
            writer = csv.DictWriter(
                output_file,
                fieldnames=OUTPUT_FIELDS,
            )
            writer.writeheader()

            for row in reader:
                if (
                    time_index >= len(row)
                    or not row[time_index].strip()
                ):
                    continue

                absolute_time = parse_finite_number(
                    row[time_index]
                )

                if absolute_time is None:
                    continue

                if first_time is None:
                    first_time = absolute_time

                relative_time = (
                    absolute_time - first_time
                )

                if relative_time < 0:
                    continue

                if relative_time > arguments.max_time:
                    break

                keep_row = (
                    valid_time_rows
                    % arguments.stride
                    == 0
                )
                valid_time_rows += 1

                if not keep_row:
                    continue

                for channel, index in (
                    channel_indices.items()
                ):
                    if (
                        index >= len(row)
                        or not row[index].strip()
                    ):
                        continue

                    value = parse_finite_number(
                        row[index]
                    )

                    if value is None:
                        continue

                    unit = (
                        units[index].strip()
                        if index < len(units)
                        else ""
                    )

                    writer.writerow(
                        {
                            "session_name": (
                                arguments.session_name
                            ),
                            "run_name": (
                                arguments.run_name
                            ),
                            "source_file": source_file,
                            "channel_name": channel,
                            "unit": unit,
                            "sample_rate_hz": (
                                number_text(
                                    output_rate_hz
                                )
                            ),
                            "timestamp_s": (
                                number_text(
                                    relative_time
                                )
                            ),
                            "value": number_text(value),
                        }
                    )

                    channel_counts[channel] += 1
                    written_rows += 1

    print(
        f"Header row detected: {header_row_number}"
    )
    print(
        f"Input sample rate: "
        f"{input_sample_rate_hz:g} Hz"
    )
    print(
        f"Output sample rate: "
        f"{output_rate_hz:g} Hz"
    )
    print(
        f"Maximum relative time: "
        f"{arguments.max_time:g} seconds"
    )
    print(f"Normalized rows written: {written_rows}")

    for channel in channels:
        print(
            f"- {channel}: "
            f"{channel_counts[channel]} rows"
        )

    print(
        f"Output size: "
        f"{arguments.output_csv.stat().st_size:,} bytes"
    )
    print(f"Output path: {arguments.output_csv}")


if __name__ == "__main__":
    main()