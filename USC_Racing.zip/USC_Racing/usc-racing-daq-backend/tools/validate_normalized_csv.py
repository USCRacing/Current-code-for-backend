import argparse
import csv
import math
from collections import Counter
from pathlib import Path


REQUIRED_COLUMNS = [
    "session_name",
    "run_name",
    "source_file",
    "channel_name",
    "unit",
    "sample_rate_hz",
    "timestamp_s",
    "value",
]

EXPECTED_CHANNEL_UNITS = {
    "Engine Speed": "rpm",
    "Vehicle Speed": "km/h",
    "Throttle Position": "%",
    "Steering Angle": "deg",
    "Wheel Speed Front Left": "mph",
    "Wheel Speed Front Right": "mph",
}

EXPECTED_SESSION = "Real Data Validation"
EXPECTED_RUN = "Lap 3 Pilot"
EXPECTED_SOURCE_FILE = "i2_lap3_validation.csv"
EXPECTED_SAMPLE_RATE = 20.0
EXPECTED_ROWS_PER_CHANNEL = 301
MAX_TIME_SECONDS = 15.0


def fail(message):
    raise SystemExit(f"Validation failed: {message}")


def main():
    parser = argparse.ArgumentParser(
        description="Validate a normalized telemetry CSV without printing values."
    )
    parser.add_argument("csv_path", type=Path)
    args = parser.parse_args()

    if not args.csv_path.is_file():
        fail("input file does not exist")

    counts = Counter()
    last_timestamp = {}
    seen_measurements = set()
    total_rows = 0

    with args.csv_path.open(
        "r",
        encoding="utf-8-sig",
        newline="",
    ) as csv_file:
        reader = csv.DictReader(csv_file)

        if reader.fieldnames != REQUIRED_COLUMNS:
            fail("column names or column order do not match the importer contract")

        for row_number, row in enumerate(reader, start=2):
            if None in row:
                fail(f"row {row_number} contains unexpected extra fields")

            if any(row[column] is None for column in REQUIRED_COLUMNS):
                fail(f"row {row_number} is missing a required field")

            if row["session_name"] != EXPECTED_SESSION:
                fail(f"row {row_number} has an unexpected session name")

            if row["run_name"] != EXPECTED_RUN:
                fail(f"row {row_number} has an unexpected run name")

            if row["source_file"] != EXPECTED_SOURCE_FILE:
                fail(f"row {row_number} has an unexpected source filename")

            channel_name = row["channel_name"]

            if channel_name not in EXPECTED_CHANNEL_UNITS:
                fail(f"row {row_number} contains an unexpected channel")

            if row["unit"] != EXPECTED_CHANNEL_UNITS[channel_name]:
                fail(f"row {row_number} has an unexpected channel unit")

            try:
                sample_rate = float(row["sample_rate_hz"])
                timestamp = float(row["timestamp_s"])
                value = float(row["value"])
            except ValueError:
                fail(f"row {row_number} contains a non-numeric numeric field")

            if not all(
                math.isfinite(number)
                for number in (sample_rate, timestamp, value)
            ):
                fail(f"row {row_number} contains a non-finite number")

            if not math.isclose(
                sample_rate,
                EXPECTED_SAMPLE_RATE,
                rel_tol=0.0,
                abs_tol=1e-9,
            ):
                fail(f"row {row_number} has an unexpected sample rate")

            if timestamp < 0 or timestamp > MAX_TIME_SECONDS + 1e-9:
                fail(f"row {row_number} is outside the pilot time range")

            previous_timestamp = last_timestamp.get(channel_name)

            if (
                previous_timestamp is not None
                and timestamp <= previous_timestamp
            ):
                fail(
                    f"row {row_number} is not strictly increasing "
                    "within its channel"
                )

            measurement_key = (channel_name, timestamp)

            if measurement_key in seen_measurements:
                fail(f"row {row_number} duplicates a channel timestamp")

            seen_measurements.add(measurement_key)
            last_timestamp[channel_name] = timestamp
            counts[channel_name] += 1
            total_rows += 1

    if set(counts) != set(EXPECTED_CHANNEL_UNITS):
        fail("the file does not contain exactly the six expected channels")

    for count in counts.values():
        if count != EXPECTED_ROWS_PER_CHANNEL:
            fail("one or more channels has an unexpected row count")

    expected_total = (
        len(EXPECTED_CHANNEL_UNITS) * EXPECTED_ROWS_PER_CHANNEL
    )

    if total_rows != expected_total:
        fail("the total row count is unexpected")

    print("Validation passed.")
    print(f"Columns: {len(REQUIRED_COLUMNS)}")
    print(f"Channels: {len(counts)}")
    print(f"Rows: {total_rows}")
    print(f"Rows per channel: {EXPECTED_ROWS_PER_CHANNEL}")
    print(f"Sample rate: {EXPECTED_SAMPLE_RATE:g} Hz")
    print(f"Time range checked: 0-{MAX_TIME_SECONDS:g} seconds")
    print("No telemetry measurement values were printed.")


if __name__ == "__main__":
    main()