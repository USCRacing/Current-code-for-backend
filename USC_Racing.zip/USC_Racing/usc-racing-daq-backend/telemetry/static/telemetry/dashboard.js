"use strict";

const runSelect = document.querySelector("#run-select");
const channelSelect = document.querySelector("#channel-select");
const startInput = document.querySelector("#start-time");
const endInput = document.querySelector("#end-time");
const loadButton = document.querySelector("#load-button");
const statusElement = document.querySelector("#dashboard-status");
const chartContainer = document.querySelector("#chart-container");
const tableBody = document.querySelector(
    "#measurement-table-body"
);

function setStatus(message, isError = false) {
    statusElement.textContent = message;
    statusElement.dataset.state = isError ? "error" : "ready";
}

async function requestJson(url) {
    const response = await fetch(url, {
        headers: {
            Accept: "application/json",
        },
    });

    let data = null;

    try {
        data = await response.json();
    } catch {
        data = null;
    }

    if (!response.ok) {
        const detail = data && typeof data === "object"
            ? Object.values(data).join(" ")
            : `Request failed with status ${response.status}.`;

        throw new Error(detail);
    }

    return data;
}

function populateSelect(select, items, labelBuilder) {
    select.replaceChildren();

    if (items.length === 0) {
        const option = document.createElement("option");
        option.textContent = "No data available";
        option.value = "";
        select.append(option);
        select.disabled = true;
        return;
    }

    for (const item of items) {
        const option = document.createElement("option");
        option.value = item.id;
        option.textContent = labelBuilder(item);
        select.append(option);
    }

    select.disabled = false;
}

const SVG_NAMESPACE = "http://www.w3.org/2000/svg";

function createSvgElement(tagName, attributes = {}, text = "") {
    const element = document.createElementNS(
        SVG_NAMESPACE,
        tagName,
    );

    for (const [name, value] of Object.entries(attributes)) {
        element.setAttribute(name, value);
    }

    if (text !== "") {
        element.textContent = text;
    }

    return element;
}

function formatTick(value) {
    return Number(value.toFixed(2)).toString();
}

function renderChart(measurements) {
    chartContainer.replaceChildren();

    if (measurements.length === 0) {
        chartContainer.textContent = "No telemetry loaded.";
        return;
    }

    const points = measurements
        .map((measurement) => ({
            x: Number(measurement.timestamp_s),
            y: Number(measurement.value),
        }))
        .filter(
            (point) =>
                Number.isFinite(point.x) &&
                Number.isFinite(point.y),
        )
        .sort((first, second) => first.x - second.x);

    if (points.length === 0) {
        chartContainer.textContent =
            "No numeric telemetry values available.";
        return;
    }

    const width = 900;
    const height = 360;
    const margin = {
        top: 52,
        right: 32,
        bottom: 52,
        left: 76,
    };

    const plotWidth = width - margin.left - margin.right;
    const plotHeight = height - margin.top - margin.bottom;

    let minimumX = Math.min(...points.map((point) => point.x));
    let maximumX = Math.max(...points.map((point) => point.x));
    let minimumY = Math.min(...points.map((point) => point.y));
    let maximumY = Math.max(...points.map((point) => point.y));

    if (minimumX === maximumX) {
        minimumX -= 0.5;
        maximumX += 0.5;
    }

    const yRange = maximumY - minimumY;
    const yPadding = yRange === 0
        ? Math.max(Math.abs(maximumY) * 0.05, 1)
        : yRange * 0.1;

    minimumY -= yPadding;
    maximumY += yPadding;

    const scaleX = (value) =>
        margin.left +
        ((value - minimumX) / (maximumX - minimumX)) *
            plotWidth;

    const scaleY = (value) =>
        margin.top +
        ((maximumY - value) / (maximumY - minimumY)) *
            plotHeight;

    const svg = createSvgElement("svg", {
        class: "telemetry-svg",
        viewBox: `0 0 ${width} ${height}`,
        role: "img",
        "aria-label": "Telemetry time-series chart",
    });

    const channelName = measurements[0].channel_name;
    const unit = measurements[0].unit || "";

    svg.append(
        createSvgElement(
            "title",
            {},
            `${channelName} telemetry over time`,
        ),
    );

    const tickCount = 4;

    for (let index = 0; index <= tickCount; index += 1) {
        const ratio = index / tickCount;
        const x = margin.left + ratio * plotWidth;
        const xValue =
            minimumX + ratio * (maximumX - minimumX);

        svg.append(
            createSvgElement("line", {
                class: "chart-grid-line",
                x1: x,
                y1: margin.top,
                x2: x,
                y2: height - margin.bottom,
            }),
        );

        svg.append(
            createSvgElement(
                "text",
                {
                    class: "chart-tick-label",
                    x,
                    y: height - margin.bottom + 24,
                    "text-anchor": "middle",
                },
                formatTick(xValue),
            ),
        );

        const y = margin.top + ratio * plotHeight;
        const yValue =
            maximumY - ratio * (maximumY - minimumY);

        svg.append(
            createSvgElement("line", {
                class: "chart-grid-line",
                x1: margin.left,
                y1: y,
                x2: width - margin.right,
                y2: y,
            }),
        );

        svg.append(
            createSvgElement(
                "text",
                {
                    class: "chart-tick-label",
                    x: margin.left - 14,
                    y: y + 4,
                    "text-anchor": "end",
                },
                formatTick(yValue),
            ),
        );
    }

    svg.append(
        createSvgElement("line", {
            class: "chart-axis-line",
            x1: margin.left,
            y1: height - margin.bottom,
            x2: width - margin.right,
            y2: height - margin.bottom,
        }),
    );

    svg.append(
        createSvgElement("line", {
            class: "chart-axis-line",
            x1: margin.left,
            y1: margin.top,
            x2: margin.left,
            y2: height - margin.bottom,
        }),
    );

    svg.append(
        createSvgElement(
            "text",
            {
                class: "chart-series-name",
                x: margin.left,
                y: 26,
            },
            channelName,
        ),
    );

    svg.append(
        createSvgElement(
            "text",
            {
                class: "chart-series-meta",
                x: width - margin.right,
                y: 26,
                "text-anchor": "end",
            },
            `${points.length} samples${unit ? ` • ${unit}` : ""}`,
        ),
    );

    svg.append(
        createSvgElement(
            "text",
            {
                class: "chart-axis-title",
                x: margin.left + plotWidth / 2,
                y: height - 8,
                "text-anchor": "middle",
            },
            "Time (s)",
        ),
    );

    svg.append(
        createSvgElement(
            "text",
            {
                class: "chart-axis-title",
                x: 18,
                y: margin.top - 16,
            },
            unit ? `Value (${unit})` : "Value",
        ),
    );

    const polylinePoints = points
        .map(
            (point) =>
                `${scaleX(point.x)},${scaleY(point.y)}`,
        )
        .join(" ");

    svg.append(
        createSvgElement("polyline", {
            class: "chart-data-line",
            points: polylinePoints,
        }),
    );

    if (points.length <= 200) {
        for (const point of points) {
            const circle = createSvgElement("circle", {
                class: "chart-data-point",
                cx: scaleX(point.x),
                cy: scaleY(point.y),
                r: 5,
            });

            circle.append(
                createSvgElement(
                    "title",
                    {},
                    `${formatTick(point.x)} s: ` +
                        `${formatTick(point.y)} ${unit}`,
                ),
            );

            svg.append(circle);
        }
    }

    chartContainer.append(svg);
}

function renderMeasurements(measurements) {
    tableBody.replaceChildren();

    if (measurements.length === 0) {
        const row = document.createElement("tr");
        const cell = document.createElement("td");

        cell.colSpan = 4;
        cell.textContent = "No measurements match the filters.";
        row.append(cell);
        tableBody.append(row);

        renderChart([]);
        return;
    }

    for (const measurement of measurements) {
        const row = document.createElement("tr");
        const values = [
            measurement.timestamp_s,
            measurement.run_name,
            measurement.channel_name,
            `${measurement.value} ${measurement.unit}`,
        ];

        for (const value of values) {
            const cell = document.createElement("td");
            cell.textContent = value;
            row.append(cell);
        }

        tableBody.append(row);
    }

    renderChart(measurements);
}

function formatChannelOption(channel) {
    return `${channel.name} (${channel.unit || "unitless"})`;
}

async function loadChannelsForSelectedRun() {
    const runId = runSelect.value;

    if (!runId) {
        populateSelect(
            channelSelect,
            [],
            formatChannelOption,
        );
        loadButton.disabled = true;
        return [];
    }

    const params = new URLSearchParams({
        run: runId,
    });

    const channels = await requestJson(
        `/api/channels/?${params.toString()}`,
    );

    populateSelect(
        channelSelect,
        channels,
        formatChannelOption,
    );

    loadButton.disabled = channels.length === 0;
    return channels;
}

async function initializeDashboard() {
    loadButton.disabled = true;
    setStatus("Loading runs and channels...");

    try {
        const runs = await requestJson("/api/runs/");

        populateSelect(
            runSelect,
            runs,
            (run) => `${run.session_name} — ${run.name}`,
        );

        if (runs.length === 0) {
            populateSelect(
                channelSelect,
                [],
                formatChannelOption,
            );
            setStatus("Ready: 0 runs and 0 channels available.");
            return;
        }

        runSelect.value = runs[runs.length - 1].id;

        const channels = await loadChannelsForSelectedRun();

        setStatus(
            `Ready: ${runs.length} runs and ` +
            `${channels.length} channels available ` +
            "for the selected run.",
        );
    } catch (error) {
        loadButton.disabled = true;
        setStatus(
            `Unable to initialize dashboard: ${error.message}`,
            true,
        );
    }
}

async function handleRunChange() {
    loadButton.disabled = true;
    renderMeasurements([]);
    setStatus("Loading channels for the selected run...");

    try {
        const channels = await loadChannelsForSelectedRun();

        setStatus(
            `Ready: ${channels.length} channels available ` +
            "for the selected run.",
        );
    } catch (error) {
        populateSelect(
            channelSelect,
            [],
            formatChannelOption,
        );
        loadButton.disabled = true;
        setStatus(
            `Unable to load channels: ${error.message}`,
            true,
        );
    }
}

async function loadTelemetry() {
    const start = startInput.value.trim();
    const end = endInput.value.trim();

    if (
        start !== "" &&
        end !== "" &&
        Number(start) > Number(end)
    ) {
        setStatus(
            "Start time cannot be greater than end time.",
            true,
        );
        return;
    }

    const params = new URLSearchParams({
        run: runSelect.value,
        channel: channelSelect.value,
    });

    if (start !== "") {
        params.set("start", start);
    }

    if (end !== "") {
        params.set("end", end);
    }

    loadButton.disabled = true;
    setStatus("Loading telemetry...");

    try {
        const measurements = await requestJson(
            `/api/measurements/?${params.toString()}`,
        );

        renderMeasurements(measurements);
        setStatus(
            `${measurements.length} measurements loaded successfully.`,
        );
    } catch (error) {
        renderMeasurements([]);
        setStatus(
            `Unable to load telemetry: ${error.message}`,
            true,
        );
    } finally {
        loadButton.disabled = false;
    }
}

runSelect.addEventListener("change", handleRunChange);
loadButton.addEventListener("click", loadTelemetry);
document.addEventListener(
    "DOMContentLoaded",
    initializeDashboard,
);