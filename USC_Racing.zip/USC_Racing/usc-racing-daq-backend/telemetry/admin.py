from django.contrib import admin

from .models import Channel, Measurement, RawFile, Run, TestSession


@admin.register(TestSession)
class TestSessionAdmin(admin.ModelAdmin):
    list_display = ("name", "test_date", "location", "created_at")
    search_fields = ("name", "location")


@admin.register(RawFile)
class RawFileAdmin(admin.ModelAdmin):
    list_display = (
        "original_name",
        "file_type",
        "file_size_bytes",
        "uploaded_at",
    )
    list_filter = ("file_type",)
    search_fields = ("original_name", "sha256")


@admin.register(Run)
class RunAdmin(admin.ModelAdmin):
    list_display = (
        "name",
        "session",
        "run_number",
        "source_file",
        "start_time",
        "end_time",
    )
    list_filter = ("session",)
    search_fields = ("name", "session__name")


@admin.register(Channel)
class ChannelAdmin(admin.ModelAdmin):
    list_display = ("name", "unit", "sample_rate_hz")
    search_fields = ("name", "unit")


@admin.register(Measurement)
class MeasurementAdmin(admin.ModelAdmin):
    list_display = ("run", "channel", "timestamp_s", "value")
    list_filter = ("run", "channel")
    search_fields = ("run__name", "channel__name")
    list_select_related = ("run", "channel")