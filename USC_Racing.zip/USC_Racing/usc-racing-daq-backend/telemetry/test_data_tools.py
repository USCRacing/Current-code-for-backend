import csv
import sys
from collections import Counter
from contextlib import redirect_stdout
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory
from unittest.mock import patch

from django.test import SimpleTestCase

from tools.normalize_i2_csv import main as normalize_main
from tools.normalize_i2_csv import parse_finite_number
from tools.validate_normalized_csv import main as validate_main


class NormalizeI2CsvTests(SimpleTestCase):
    def test_parse_finite_number_accepts_valid_numbers(self):
        self.assertEqual(parse_finite_number("0"), 0.0)
        self.assertEqual(parse_finite_number("12.5"), 12.5)
        self.assertEqual(parse_finite_number("-2.75"), -2.75)

    def test_parse_finite_number_rejects_invalid_numbers(self):
        invalid_values = [
            None,
            "",
            "not-a-number",
            "nan",
            "inf",
            "-inf",
        ]

        for value in invalid_values:
            with self.subTest(value=value):
                self.assertIsNone(parse_finite_number(value))

    def test_rejects_non_positive_stride(self):
        arguments = [
            "normalize_i2_csv.py",
            "input.csv",
            "output.csv",
            "--stride",
            "0",
        ]

        with patch.object(sys, "argv", arguments):
            with self.assertRaises(SystemExit) as context:
                normalize_main()

        self.assertEqual(
            str(context.exception),
            "--stride must be a positive integer.",
        )

    def test_rejects_non_positive_max_time(self):
        arguments = [
            "normalize_i2_csv.py",
            "input.csv",
            "output.csv",
            "--max-time",
            "0",
        ]

        with patch.object(sys, "argv", arguments):
            with self.assertRaises(SystemExit) as context:
                normalize_main()

        self.assertEqual(
            str(context.exception),
            "--max-time must be positive.",
        )

    def test_normalizes_and_validates_channels_end_to_end(self):
        expected_channel_units = {
            "Engine Speed": "rpm",
            "Vehicle Speed": "km/h",
            "Throttle Position": "%",
            "Steering Angle": "deg",
            "Wheel Speed Front Left": "mph",
            "Wheel Speed Front Right": "mph",
        }

        with TemporaryDirectory() as temporary_directory:
            temporary_path = Path(temporary_directory)
            input_path = temporary_path / "i2_export.csv"
            output_path = temporary_path / "normalized.csv"

            with input_path.open(
                "w",
                encoding="utf-8",
                newline="",
            ) as input_file:
                writer = csv.writer(input_file)
                writer.writerow(
                    ["Export", "Automated pilot fixture"]
                )
                writer.writerow(["Sample Rate", "200"])
                writer.writerow(
                    [
                        "Time",
                        *expected_channel_units.keys(),
                    ]
                )
                writer.writerow(
                    [
                        "s",
                        *expected_channel_units.values(),
                    ]
                )

                for sample_index in range(3001):
                    timestamp = (
                        100.0 + sample_index / 200.0
                    )

                    writer.writerow(
                        [
                            f"{timestamp:.3f}",
                            3000 + sample_index,
                            50 + sample_index / 100,
                            40,
                            0,
                            45,
                            45,
                        ]
                    )

            normalize_arguments = [
                "normalize_i2_csv.py",
                str(input_path),
                str(output_path),
                "--stride",
                "10",
                "--max-time",
                "15",
                "--session-name",
                "Real Data Validation",
                "--run-name",
                "Lap 3 Pilot",
                "--source-file",
                "i2_lap3_validation.csv",
            ]

            normalize_console = StringIO()

            with patch.object(
                sys,
                "argv",
                normalize_arguments,
            ):
                with redirect_stdout(normalize_console):
                    normalize_main()

            self.assertTrue(output_path.is_file())

            with output_path.open(
                "r",
                encoding="utf-8",
                newline="",
            ) as output_file:
                reader = csv.DictReader(output_file)
                fieldnames = reader.fieldnames
                rows = list(reader)

            self.assertEqual(
                fieldnames,
                [
                    "session_name",
                    "run_name",
                    "source_file",
                    "channel_name",
                    "unit",
                    "sample_rate_hz",
                    "timestamp_s",
                    "value",
                ],
            )
            self.assertEqual(len(rows), 1806)

            rows_per_channel = Counter(
                row["channel_name"] for row in rows
            )
            self.assertEqual(
                rows_per_channel,
                Counter(
                    {
                        channel: 301
                        for channel
                        in expected_channel_units
                    }
                ),
            )

            units_by_channel = {
                row["channel_name"]: row["unit"]
                for row in rows
            }
            self.assertEqual(
                units_by_channel,
                expected_channel_units,
            )

            self.assertEqual(
                {
                    row["session_name"]
                    for row in rows
                },
                {"Real Data Validation"},
            )
            self.assertEqual(
                {
                    row["run_name"]
                    for row in rows
                },
                {"Lap 3 Pilot"},
            )
            self.assertEqual(
                {
                    row["source_file"]
                    for row in rows
                },
                {"i2_lap3_validation.csv"},
            )
            self.assertEqual(
                {
                    row["sample_rate_hz"]
                    for row in rows
                },
                {"20"},
            )

            for channel in expected_channel_units:
                timestamps = [
                    float(row["timestamp_s"])
                    for row in rows
                    if row["channel_name"] == channel
                ]

                self.assertEqual(len(timestamps), 301)
                self.assertAlmostEqual(
                    timestamps[0],
                    0.0,
                    places=9,
                )
                self.assertAlmostEqual(
                    timestamps[-1],
                    15.0,
                    places=9,
                )

            self.assertIn(
                "Input sample rate: 200 Hz",
                normalize_console.getvalue(),
            )
            self.assertIn(
                "Output sample rate: 20 Hz",
                normalize_console.getvalue(),
            )
            self.assertIn(
                "Normalized rows written: 1806",
                normalize_console.getvalue(),
            )

            validate_arguments = [
                "validate_normalized_csv.py",
                str(output_path),
            ]
            validate_console = StringIO()

            with patch.object(
                sys,
                "argv",
                validate_arguments,
            ):
                with redirect_stdout(validate_console):
                    validate_main()

            self.assertIn(
                "Validation passed.",
                validate_console.getvalue(),
            )
            self.assertIn(
                "Rows: 1806",
                validate_console.getvalue(),
            )


class ValidateNormalizedCsvTests(SimpleTestCase):
    def test_rejects_missing_input_file(self):
        with TemporaryDirectory() as temporary_directory:
            missing_path = (
                Path(temporary_directory)
                / "missing_normalized.csv"
            )
            arguments = [
                "validate_normalized_csv.py",
                str(missing_path),
            ]

            with patch.object(sys, "argv", arguments):
                with self.assertRaises(SystemExit) as context:
                    validate_main()

        self.assertEqual(
            str(context.exception),
            "Validation failed: input file does not exist",
        )