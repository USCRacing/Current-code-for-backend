from django.urls import path

from .views import (
    ChannelListAPIView,
    MeasurementListAPIView,
    RunListAPIView,
)


app_name = "telemetry"

urlpatterns = [
    path(
        "runs/",
        RunListAPIView.as_view(),
        name="run-list",
    ),
    path(
        "channels/",
        ChannelListAPIView.as_view(),
        name="channel-list",
    ),
    path(
        "measurements/",
        MeasurementListAPIView.as_view(),
        name="measurement-list",
    ),
]