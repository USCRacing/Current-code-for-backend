from rest_framework import generics
from rest_framework.exceptions import ValidationError

from .models import Channel, Measurement, Run
from .serializers import (
    ChannelSerializer,
    MeasurementSerializer,
    RunSerializer,
)


class RunListAPIView(generics.ListAPIView):
    serializer_class = RunSerializer
    queryset = (
        Run.objects
        .select_related("session", "source_file")
        .order_by("id")
    )


class ChannelListAPIView(generics.ListAPIView):
    serializer_class = ChannelSerializer

    def get_queryset(self):
        queryset = Channel.objects.order_by("name", "unit", "id")
        run_id = self.request.query_params.get("run")

        if run_id:
            try:
                run_id = int(run_id)
            except ValueError:
                raise ValidationError(
                    {"run": "Run must be an integer ID."}
                )

            channel_ids = Measurement.objects.filter(
                run_id=run_id
            ).values_list("channel_id", flat=True)

            queryset = queryset.filter(id__in=channel_ids)

        return queryset


class MeasurementListAPIView(generics.ListAPIView):
    serializer_class = MeasurementSerializer

    def get_queryset(self):
        queryset = Measurement.objects.select_related(
            "run",
            "channel",
        )

        run_id = self.request.query_params.get("run")
        channel_id = self.request.query_params.get("channel")
        start = self.request.query_params.get("start")
        end = self.request.query_params.get("end")

        if run_id:
            try:
                run_id = int(run_id)
            except ValueError:
                raise ValidationError(
                    {"run": "Run must be an integer ID."}
                )
            queryset = queryset.filter(run_id=run_id)

        if channel_id:
            try:
                channel_id = int(channel_id)
            except ValueError:
                raise ValidationError(
                    {"channel": "Channel must be an integer ID."}
                )
            queryset = queryset.filter(channel_id=channel_id)

        if start is not None:
            try:
                start = float(start)
            except ValueError:
                raise ValidationError(
                    {"start": "Start must be a number."}
                )
            queryset = queryset.filter(timestamp_s__gte=start)

        if end is not None:
            try:
                end = float(end)
            except ValueError:
                raise ValidationError(
                    {"end": "End must be a number."}
                )
            queryset = queryset.filter(timestamp_s__lte=end)

        if start is not None and end is not None and start > end:
            raise ValidationError(
                {"time_range": "Start cannot be greater than end."}
            )

        return queryset.order_by(
            "timestamp_s",
            "channel__name",
            "id",
        )