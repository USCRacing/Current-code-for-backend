from django.contrib.staticfiles import finders
from django.test import SimpleTestCase
from django.urls import reverse


class DashboardPageTests(SimpleTestCase):
    def test_dashboard_page_is_available(self):
        response = self.client.get(reverse("dashboard"))

        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(
            response,
            "telemetry/dashboard.html",
        )
        self.assertContains(
            response,
            "DAQ Telemetry Dashboard",
        )

    def test_dashboard_assets_are_discoverable(self):
        self.assertIsNotNone(
            finders.find("telemetry/dashboard.css")
        )
        self.assertIsNotNone(
            finders.find("telemetry/dashboard.js")
        )