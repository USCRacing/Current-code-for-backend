import csv
from pathlib import Path

from django.core.management.base import BaseCommand, CommandError
from django.db import transaction

from telemetry.models import (
    Channel,
    Measurement,
    RawFile,
    Run,
    TestSession,
)

REQUIRED_COLUMNS = {
    "session_name",
    "run_name",
    "source_file",
    "channel_name",
    "unit",
    "sample_rate_hz",
    "timestamp_s",
    "value",
}


class Command(BaseCommand):
    help = "Import normalized telemetry data from a CSV file."

    def add_arguments(self, parser):
        parser.add_argument("csv_path", type=Path)

    def handle(self, *args, **options):
        csv_path = options["csv_path"]

        if not csv_path.is_file():
            raise CommandError(f"CSV file not found: {csv_path}")

        with csv_path.open(
            mode="r",
            encoding="utf-8-sig",
            newline="",
        ) as csv_file:
            reader = csv.DictReader(csv_file)

            if reader.fieldnames is None:
                raise CommandError("CSV file does not contain a header row.")

            missing_columns = REQUIRED_COLUMNS - set(reader.fieldnames)

            if missing_columns:
                missing_text = ", ".join(sorted(missing_columns))
                raise CommandError(
                    f"Missing required columns: {missing_text}"
                )

            rows = list(reader)

        if not rows:
            raise CommandError("CSV file contains no data rows.")

        text_fields = (
            "session_name",
            "run_name",
            "source_file",
            "channel_name",
        )

        for line_number, row in enumerate(rows, start=2):
            empty_fields = [
                field
                for field in text_fields
                if not (row.get(field) or "").strip()
            ]

            if empty_fields:
                empty_text = ", ".join(empty_fields)
                raise CommandError(
                    f"Line {line_number} has empty fields: {empty_text}"
                )

            try:
                sample_rate_hz = float(row["sample_rate_hz"])
                timestamp_s = float(row["timestamp_s"])
                float(row["value"])
            except (TypeError, ValueError):
                raise CommandError(
                    f"Line {line_number} contains an invalid number."
                )

            if sample_rate_hz <= 0:
                raise CommandError(
                    f"Line {line_number}: sample_rate_hz must be positive."
                )

            if timestamp_s < 0:
                raise CommandError(
                    f"Line {line_number}: timestamp_s cannot be negative."
                )

            created_counts = {
            "sessions": 0,
            "raw_files": 0,
            "runs": 0,
            "channels": 0,
            "measurements": 0,
        }
        updated_measurements = 0

        with transaction.atomic():
            for row in rows:
                session_name = row["session_name"].strip()
                run_name = row["run_name"].strip()
                source_file = row["source_file"].strip()
                channel_name = row["channel_name"].strip()
                unit = (row.get("unit") or "").strip()

                sample_rate_hz = float(row["sample_rate_hz"])
                timestamp_s = float(row["timestamp_s"])
                value = float(row["value"])

                session, created = TestSession.objects.get_or_create(
                    name=session_name
                )
                if created:
                    created_counts["sessions"] += 1

                file_type = {
                    ".ld": RawFile.FileType.LD,
                    ".ldx": RawFile.FileType.LDX,
                    ".csv": RawFile.FileType.CSV,
                }.get(
                    Path(source_file).suffix.lower(),
                    RawFile.FileType.OTHER,
                )

                raw_file, created = RawFile.objects.get_or_create(
                    original_name=source_file,
                    defaults={"file_type": file_type},
                )
                if created:
                    created_counts["raw_files"] += 1

                run, created = Run.objects.get_or_create(
                    session=session,
                    name=run_name,
                    defaults={"source_file": raw_file},
                )
                if created:
                    created_counts["runs"] += 1
                elif run.source_file_id is None:
                    run.source_file = raw_file
                    run.save(update_fields=["source_file"])
                elif run.source_file_id != raw_file.id:
                    raise CommandError(
                        f"Run '{run_name}' is already linked "
                        "to a different source file."
                    )

                channel, created = Channel.objects.get_or_create(
                    name=channel_name,
                    unit=unit,
                    defaults={"sample_rate_hz": sample_rate_hz},
                )
                if created:
                    created_counts["channels"] += 1
                elif channel.sample_rate_hz is None:
                    channel.sample_rate_hz = sample_rate_hz
                    channel.save(update_fields=["sample_rate_hz"])

                measurement, created = (
                    Measurement.objects.update_or_create(
                        run=run,
                        channel=channel,
                        timestamp_s=timestamp_s,
                        defaults={"value": value},
                    )
                )

                if created:
                    created_counts["measurements"] += 1
                else:
                    updated_measurements += 1

        summary = "\n".join(
            [
                f"Imported {len(rows)} telemetry rows.",
                f"New sessions: {created_counts['sessions']}",
                f"New raw files: {created_counts['raw_files']}",
                f"New runs: {created_counts['runs']}",
                f"New channels: {created_counts['channels']}",
                (
                    "New measurements: "
                    f"{created_counts['measurements']}"
                ),
                f"Updated measurements: {updated_measurements}",
            ]
        )

        self.stdout.write(self.style.SUCCESS(summary))