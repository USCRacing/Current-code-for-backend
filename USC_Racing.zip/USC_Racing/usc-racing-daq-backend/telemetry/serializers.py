from rest_framework import serializers

from .models import Channel, Measurement, Run


class RunSerializer(serializers.ModelSerializer):
    session_name = serializers.CharField(
        source="session.name",
        read_only=True,
    )
    source_file_name = serializers.CharField(
        source="source_file.original_name",
        read_only=True,
    )

    class Meta:
        model = Run
        fields = [
            "id",
            "name",
            "run_number",
            "session",
            "session_name",
            "source_file",
            "source_file_name",
            "start_time",
            "end_time",
            "notes",
        ]


class ChannelSerializer(serializers.ModelSerializer):
    class Meta:
        model = Channel
        fields = [
            "id",
            "name",
            "unit",
            "sample_rate_hz",
            "description",
        ]


class MeasurementSerializer(serializers.ModelSerializer):
    run_name = serializers.CharField(
        source="run.name",
        read_only=True,
    )
    channel_name = serializers.CharField(
        source="channel.name",
        read_only=True,
    )
    unit = serializers.CharField(
        source="channel.unit",
        read_only=True,
    )

    class Meta:
        model = Measurement
        fields = [
            "id",
            "run",
            "run_name",
            "channel",
            "channel_name",
            "unit",
            "timestamp_s",
            "value",
        ]