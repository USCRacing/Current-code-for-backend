import csv
from io import StringIO
from pathlib import Path
from tempfile import TemporaryDirectory

from django.core.management import call_command
from django.core.management.base import CommandError
from django.test import TestCase

from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase

from .models import (
    Channel,
    Measurement,
    RawFile,
    Run,
    TestSession,
)


class TelemetryAPITests(APITestCase):
    def setUp(self):
        self.test_session = TestSession.objects.create(
            name="Automated Test Session",
            location="USC Racing Shop",
        )

        self.raw_file = RawFile.objects.create(
            original_name="automated_test.csv",
            file_type=RawFile.FileType.CSV,
        )

        self.run = Run.objects.create(
            session=self.test_session,
            source_file=self.raw_file,
            name="Automated Test Run",
            run_number=1,
        )

        self.rpm_channel = Channel.objects.create(
            name="Engine RPM",
            unit="rpm",
            sample_rate_hz=10,
        )

        self.speed_channel = Channel.objects.create(
            name="Vehicle Speed",
            unit="kph",
            sample_rate_hz=10,
        )

        Measurement.objects.bulk_create(
            [
                Measurement(
                    run=self.run,
                    channel=self.rpm_channel,
                    timestamp_s=0.0,
                    value=3000,
                ),
                Measurement(
                    run=self.run,
                    channel=self.rpm_channel,
                    timestamp_s=0.1,
                    value=3150,
                ),
                Measurement(
                    run=self.run,
                    channel=self.rpm_channel,
                    timestamp_s=0.2,
                    value=3300,
                ),
                Measurement(
                    run=self.run,
                    channel=self.speed_channel,
                    timestamp_s=0.0,
                    value=0,
                ),
                Measurement(
                    run=self.run,
                    channel=self.speed_channel,
                    timestamp_s=0.1,
                    value=12.5,
                ),
                Measurement(
                    run=self.run,
                    channel=self.speed_channel,
                    timestamp_s=0.2,
                    value=25,
                ),
            ]
        )

    def test_run_list(self):
        url = reverse("telemetry:run-list")
        response = self.client.get(url)

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )
        self.assertEqual(len(response.data), 1)
        self.assertEqual(
            response.data[0]["name"],
            "Automated Test Run",
        )
        self.assertEqual(
            response.data[0]["session_name"],
            "Automated Test Session",
        )
        self.assertEqual(
            response.data[0]["source_file_name"],
            "automated_test.csv",
        )

    def test_channel_list(self):
        url = reverse("telemetry:channel-list")
        response = self.client.get(url)

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )
        self.assertEqual(len(response.data), 2)
        self.assertEqual(
            [channel["name"] for channel in response.data],
            ["Engine RPM", "Vehicle Speed"],
        )

    def test_channel_list_can_filter_by_run(self):
        unrelated_channel = Channel.objects.create(
            name="Unrelated Channel",
            unit="test",
            sample_rate_hz=1.0,
        )

        url = reverse("telemetry:channel-list")
        response = self.client.get(
            url,
            {"run": self.run.id},
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )

        returned_ids = {
            channel["id"] for channel in response.data
        }

        self.assertSetEqual(
            returned_ids,
            {
                self.rpm_channel.id,
                self.speed_channel.id,
            },
        )
        self.assertNotIn(
            unrelated_channel.id,
            returned_ids,
        )

    def test_measurement_list_can_filter_by_run(self):
        url = reverse("telemetry:measurement-list")
        response = self.client.get(
            url,
            {"run": self.run.id},
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )
        self.assertEqual(len(response.data), 6)
        self.assertTrue(
            all(
                measurement["run"] == self.run.id
                for measurement in response.data
            )
        )

    def test_measurement_list_can_filter_by_channel_and_time(self):
        url = reverse("telemetry:measurement-list")
        response = self.client.get(
            url,
            {
                "run": self.run.id,
                "channel": self.speed_channel.id,
                "start": 0.1,
                "end": 0.2,
            },
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_200_OK,
        )
        self.assertEqual(len(response.data), 2)
        self.assertEqual(
            [
                measurement["timestamp_s"]
                for measurement in response.data
            ],
            [0.1, 0.2],
        )
        self.assertEqual(
            [
                measurement["value"]
                for measurement in response.data
            ],
            [12.5, 25.0],
        )
        self.assertTrue(
            all(
                measurement["channel_name"] == "Vehicle Speed"
                for measurement in response.data
            )
        )

    def test_invalid_time_range_returns_bad_request(self):
        url = reverse("telemetry:measurement-list")
        response = self.client.get(
            url,
            {
                "run": self.run.id,
                "start": 0.2,
                "end": 0.1,
            },
        )

        self.assertEqual(
            response.status_code,
            status.HTTP_400_BAD_REQUEST,
        )
        self.assertIn("time_range", response.data)
        self.assertEqual(
            str(response.data["time_range"]),
            "Start cannot be greater than end.",
        )

class ImportTelemetryCommandTests(TestCase):
    fieldnames = [
        "session_name",
        "run_name",
        "source_file",
        "channel_name",
        "unit",
        "sample_rate_hz",
        "timestamp_s",
        "value",
    ]

    def setUp(self):
        self.temp_directory = TemporaryDirectory()
        self.addCleanup(self.temp_directory.cleanup)

        self.csv_path = (
            Path(self.temp_directory.name) / "test_telemetry.csv"
        )
        self.command_output = StringIO()

    def write_csv(self, rows, fieldnames=None):
        selected_fieldnames = fieldnames or self.fieldnames

        with self.csv_path.open(
            "w",
            newline="",
            encoding="utf-8",
        ) as csv_file:
            writer = csv.DictWriter(
                csv_file,
                fieldnames=selected_fieldnames,
            )
            writer.writeheader()
            writer.writerows(rows)

    def test_valid_csv_creates_expected_records(self):
        rows = [
            {
                "session_name": "Automated Import Session",
                "run_name": "Automated Import Run",
                "source_file": "automated_import.csv",
                "channel_name": "Engine RPM",
                "unit": "rpm",
                "sample_rate_hz": "10",
                "timestamp_s": "0.0",
                "value": "3000",
            },
            {
                "session_name": "Automated Import Session",
                "run_name": "Automated Import Run",
                "source_file": "automated_import.csv",
                "channel_name": "Engine RPM",
                "unit": "rpm",
                "sample_rate_hz": "10",
                "timestamp_s": "0.1",
                "value": "3150",
            },
        ]

        self.write_csv(rows)

        call_command(
            "import_telemetry",
            str(self.csv_path),
            stdout=self.command_output,
        )

        self.assertEqual(TestSession.objects.count(), 1)
        self.assertEqual(RawFile.objects.count(), 1)
        self.assertEqual(Run.objects.count(), 1)
        self.assertEqual(Channel.objects.count(), 1)
        self.assertEqual(Measurement.objects.count(), 2)

        measurement_values = list(
            Measurement.objects
            .order_by("timestamp_s")
            .values_list("value", flat=True)
        )

        self.assertEqual(measurement_values, [3000.0, 3150.0])

    def test_reimport_updates_without_creating_duplicates(self):
        rows = [
            {
            "session_name": "Repeat Import Session",
            "run_name": "Repeat Import Run",
            "source_file": "repeat_import.csv",
            "channel_name": "Vehicle Speed",
            "unit": "kph",
            "sample_rate_hz": "10",
            "timestamp_s": "0.0",
            "value": "20.0",
            }
         ]

        self.write_csv(rows)

        call_command(
            "import_telemetry",
            str(self.csv_path),
            stdout=self.command_output,
            )

        rows[0]["value"] = "25.0"
        self.write_csv(rows)

        call_command(
            "import_telemetry",
            str(self.csv_path),
            stdout=self.command_output,
            )

        self.assertEqual(TestSession.objects.count(), 1)
        self.assertEqual(RawFile.objects.count(), 1)
        self.assertEqual(Run.objects.count(), 1)
        self.assertEqual(Channel.objects.count(), 1)
        self.assertEqual(Measurement.objects.count(), 1)

        measurement = Measurement.objects.get()
        self.assertEqual(measurement.value, 25.0)

    def test_missing_required_column_is_rejected(self):
        incomplete_fieldnames = [
            "session_name",
            "run_name",
            "source_file",
            "channel_name",
            "unit",
            "sample_rate_hz",
            "timestamp_s",
        ]

        rows = [
            {
                "session_name": "Invalid Import Session",
                "run_name": "Invalid Import Run",
                "source_file": "missing_value.csv",
                "channel_name": "Engine RPM",
                "unit": "rpm",
                "sample_rate_hz": "10",
                "timestamp_s": "0.0",
            }
        ]

        self.write_csv(
            rows,
            fieldnames=incomplete_fieldnames,
        )

        with self.assertRaises(CommandError):
            call_command(
                "import_telemetry",
                str(self.csv_path),
                stdout=self.command_output,
            )

        self.assertEqual(TestSession.objects.count(), 0)
        self.assertEqual(RawFile.objects.count(), 0)
        self.assertEqual(Run.objects.count(), 0)
        self.assertEqual(Channel.objects.count(), 0)
        self.assertEqual(Measurement.objects.count(), 0)

    def test_invalid_row_rolls_back_entire_import(self):
        rows = [
            {
                "session_name": "Rollback Test Session",
                "run_name": "Rollback Test Run",
                "source_file": "rollback_test.csv",
                "channel_name": "Engine RPM",
                "unit": "rpm",
                "sample_rate_hz": "10",
                "timestamp_s": "0.0",
                "value": "3000",
            },
            {
                "session_name": "Rollback Test Session",
                "run_name": "Rollback Test Run",
                "source_file": "rollback_test.csv",
                "channel_name": "Engine RPM",
                "unit": "rpm",
                "sample_rate_hz": "10",
                "timestamp_s": "-0.1",
                "value": "3100",
            },
        ]

        self.write_csv(rows)

        with self.assertRaises(CommandError):
            call_command(
                "import_telemetry",
                str(self.csv_path),
                stdout=self.command_output,
            )

        self.assertEqual(TestSession.objects.count(), 0)
        self.assertEqual(RawFile.objects.count(), 0)
        self.assertEqual(Run.objects.count(), 0)
        self.assertEqual(Channel.objects.count(), 0)
        self.assertEqual(Measurement.objects.count(), 0)