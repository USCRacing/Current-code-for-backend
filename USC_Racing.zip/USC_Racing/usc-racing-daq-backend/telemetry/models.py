from django.db import models


class TestSession(models.Model):
    name = models.CharField(max_length=120)
    test_date = models.DateField(null=True, blank=True)
    location = models.CharField(max_length=120, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.name


class RawFile(models.Model):
    class FileType(models.TextChoices):
        LD = "ld", ".ld"
        LDX = "ldx", ".ldx"
        CSV = "csv", ".csv"
        OTHER = "other", "Other"

    original_name = models.CharField(max_length=255)
    file_type = models.CharField(
        max_length=10,
        choices=FileType.choices,
        default=FileType.OTHER,
    )
    file_size_bytes = models.PositiveBigIntegerField(
        null=True,
        blank=True,
    )
    sha256 = models.CharField(max_length=64, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.original_name

class Run(models.Model):
    session = models.ForeignKey(
        TestSession,
        on_delete=models.CASCADE,
        related_name="runs",
    )
    source_file = models.ForeignKey(
        RawFile,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name="runs",
    )
    name = models.CharField(max_length=120)
    run_number = models.PositiveIntegerField(null=True, blank=True)
    start_time = models.DateTimeField(null=True, blank=True)
    end_time = models.DateTimeField(null=True, blank=True)
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.session.name} - {self.name}"


class Channel(models.Model):
    name = models.CharField(max_length=120)
    unit = models.CharField(max_length=32, blank=True)
    sample_rate_hz = models.FloatField(null=True, blank=True)
    description = models.TextField(blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["name", "unit"],
                name="unique_channel_name_unit",
            )
        ]
        ordering = ["name"]

    def __str__(self):
        if self.unit:
            return f"{self.name} ({self.unit})"
        return self.name


class Measurement(models.Model):
    run = models.ForeignKey(
        Run,
        on_delete=models.CASCADE,
        related_name="measurements",
    )
    channel = models.ForeignKey(
        Channel,
        on_delete=models.PROTECT,
        related_name="measurements",
    )
    timestamp_s = models.FloatField()
    value = models.FloatField()

    class Meta:
        indexes = [
            models.Index(
                fields=["run", "channel", "timestamp_s"],
                name="measurement_lookup_idx",
            )
        ]
        ordering = ["run_id", "channel_id", "timestamp_s"]

    def __str__(self):
        return (
            f"{self.run.name} - {self.channel.name} "
            f"at {self.timestamp_s}s: {self.value}"
        )