# USC Racing DAQ Server Back-End

Local Django prototype for importing, storing, and querying USC Racing DAQ telemetry data.

## Current Data Flow

```text
.ld / .ldx files
    → exported or normalized CSV
    → Django importer
    → SQLite database
    → read-only REST API
```

Raw `.ld` and `.ldx` parsing is currently handled outside this backend.
The backend accepts a normalized long-format CSV.

## Implemented Features

- Django database models:
  - `RawFile`
  - `TestSession`
  - `Run`
  - `Channel`
  - `Measurement`
- Django Admin interface
- Validated CSV importer
- Transactional database import
- Idempotent repeated imports
- Read-only REST API
- Run, Channel, and time-range filtering
- Automated API tests

## Technology

- Python 3.12
- Django 6.1
- Django REST Framework 3.18
- SQLite for local development

## Environment Setup

Create and activate the Conda environment:

```bash
conda create --name usc-racing-backend python=3.12 -y
conda activate usc-racing-backend
```

Install dependencies:

```bash
python -m pip install -r requirements.txt
```

Apply database migrations:

```bash
python manage.py migrate
```

Optional: create an Admin account:

```bash
python manage.py createsuperuser
```

## Running the Server

```bash
python manage.py runserver
```

Local addresses:

- Admin: `http://127.0.0.1:8000/admin/`
- Runs API: `http://127.0.0.1:8000/api/runs/`
- Channels API: `http://127.0.0.1:8000/api/channels/`
- Measurements API: `http://127.0.0.1:8000/api/measurements/`

## Normalized CSV Format

Required columns:

| Column | Meaning |
|---|---|
| `session_name` | Test session name |
| `run_name` | Run name |
| `source_file` | Source filename |
| `channel_name` | Telemetry channel name |
| `unit` | Measurement unit |
| `sample_rate_hz` | Sampling frequency |
| `timestamp_s` | Time relative to run start |
| `value` | Measurement value |

Example:

```csv
session_name,run_name,source_file,channel_name,unit,sample_rate_hz,timestamp_s,value
Backend Demo Session,Imported Demo Run,backend_demo_import.csv,Engine RPM,rpm,10,0.0,3000
Backend Demo Session,Imported Demo Run,backend_demo_import.csv,Vehicle Speed,kph,10,0.0,0
```

## Importing Telemetry

```bash
python manage.py import_telemetry sample_data\demo_telemetry.csv
```

The importer:

- validates required columns;
- validates numeric values;
- rejects negative timestamps;
- rejects non-positive sample rates;
- uses a database transaction;
- reuses existing Session, Run, RawFile, and Channel records;
- creates or updates Measurements without duplication.

## API Query Parameters

The Measurements API accepts:

| Parameter | Meaning |
|---|---|
| `run` | Run ID |
| `channel` | Channel ID |
| `start` | Inclusive minimum timestamp |
| `end` | Inclusive maximum timestamp |

Example:

```text
http://127.0.0.1:8000/api/measurements/?run=2&channel=2&start=0.1&end=0.2
```

The API returns `400 Bad Request` when query parameters are invalid.

## Running Tests

```bash
python manage.py test telemetry
```

The tests use a temporary database and do not modify local development data.

Current automated coverage verifies:

- Run list output
- Channel list output
- Measurement filtering by Run
- Measurement filtering by Channel and time
- Invalid time-range handling

## Project Structure

```text
usc-racing-daq-backend/
├── config/                     # Project settings and root URLs
├── sample_data/                # Synthetic normalized CSV
├── telemetry/
│   ├── management/commands/    # CSV importer
│   ├── migrations/             # Database schema history
│   ├── admin.py                # Admin configuration
│   ├── models.py               # Data models
│   ├── serializers.py          # JSON serialization
│   ├── tests.py                # Automated tests
│   ├── urls.py                 # API routes
│   └── views.py                # API query logic
├── db.sqlite3                  # Local development database
├── manage.py
├── README.md
└── requirements.txt
```

## Current Limitations

- Uses SQLite for local development.
- Does not directly parse proprietary `.ld` or `.ldx` files.
- Real i2 export format still needs to be mapped to the normalized CSV schema.
- API is currently read-only.
- Production authentication and deployment settings are not yet configured.